export const environment = {
  production: false,
  enableAllRoutes: false,
  enableLimitedRoutes: true,
  apiBaseUrl: 'http://localhost:8090'
};
