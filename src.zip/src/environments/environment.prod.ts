export const environment = {
  production: true,
  enableAllRoutes: false,
  enableLimitedRoutes: true,
  apiBaseUrl: ''
};
