export const environment = {
  production: false,
  enableAllRoutes: false,
  enableLimitedRoutes: true,
  apiBaseUrl: ''
};
