import {Component} from '@angular/core';

@Component({
  selector: 'app-msp',
  templateUrl: './msp.component.html',
  styleUrls: ['./msp.component.scss']
})
export class MspComponent {}
