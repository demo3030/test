import {Component, OnInit} from '@angular/core';
import {UrlManager} from '../../utils/shared-constants.model';
import {Router} from '@angular/router';
import {MenuItem} from 'primeng/api';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  urlMngr: UrlManager;
  isLoggedIn = true;
  username = 'Test User';

  items: MenuItem[] = [];

  constructor(private router: Router) {
    this.urlMngr = new UrlManager();
  }

  ngOnInit(): void {
    this.items = [
      {
        label: 'RELEASE',
        routerLink: this.urlMngr.getModuleUrl('RELEASE')
      },
      {
        label: 'CDS',
        routerLink: this.urlMngr.getModuleUrl('CDS')
      },
      {
        label: 'MSP',
        routerLink: this.urlMngr.getModuleUrl('MSP')
      },
      {
        label: 'HCR',
        routerLink: this.urlMngr.getModuleUrl('HCR')
      },
      {
        label: 'DRR',
        routerLink: this.urlMngr.getModuleUrl('DRR')
      }
    ];
  }

  navigateTo(url: string) {
    if (url === null || typeof url === 'undefined' || url === '') return;
    this.router.navigate([this.urlMngr.getModuleUrl(url)]);
  }

  onLogin() {
    // Login functionality here
  }

  onLogout() {
    Swal.fire({
      icon: 'warning',
      title: 'Warning',
      text: 'Authentication Module Implementation is in Progress!!',
      confirmButtonColor: '#00467f'
    }).then(() => {
      document.body.style.overflow = 'auto';
      this.router.navigate(['/']);
    });
  }
}
