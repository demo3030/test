import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FileDownloadService {
  openFile(path: string) {
    const fileMapping: Record<string, string> = {
      'bulk-mail-guide': 'assets/release/rel_proc/Bulk Mail Guide.pdf',
      'process-owners':
        'https://www.lom.ford.com/launchomatic/launch/view.jsp?chronicleId=0900cad9811eb0ae&amp;docbase=edmsna1',
      'gpcse-module-release-process':
        'assets/release/rel_proc/GPCSE Module Release Process.pdf?v4',
      'jira-service-desk':
        'https://ford.atlassian.net/servicedesk/customer/portal/1147',
      'module-release-sharepoint':
        'https://azureford.sharepoint.com/sites/GPCSEModuleRelease'
    };

    const fileUrl = fileMapping[path];
    if (fileUrl) {
      // Open the file in a new tab
      const newWindow = window.open(fileUrl, '_blank');
      if (newWindow) {
        newWindow.focus();
      } else {
        console.error(
          'Failed to open the file in a new tab. Popup might be blocked.'
        );
      }
    } else {
      console.error('File not found for path:', path);
    }
  }
}
