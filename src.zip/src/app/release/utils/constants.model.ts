export class ReleaseConstants {}
