export class FirmwareExportForm {
  exportVersion = 10;
  exportFilename!: string;
  concernNumber!: string;
  wersNoticeNumber!: string;
  partNumbers: string[] = Array(9).fill('');
}

export class ExportToXmlPostModel {
  partNumbers: string[] = [];
  exportFilename = '';
  concernNumber = '';
  wersNoticeNumber = '';
  exportVersion = 10;
  createUser = '';
}
