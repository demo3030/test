export class ReleaseSideBarMenuChildren {
  id = '';
  name = '';
  url = '';
  isDisabled=true;
}

export class ReleaseSideBarMenuModel {
  id = '';
  name = '';
  children = new Array<ReleaseSideBarMenuChildren>();
  url = '';
  iconName = '';
  
}
