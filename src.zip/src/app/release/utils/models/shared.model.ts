export class SupplierOptionsModel {
  supplierName = '';
  supplierCode = '';
}
export class ModuleTypesOptionsModel {
  moduleTypeName = '';
  moduleTypeCode = '';
}
export class MicroTypesOptionModel {
  microTypeCode = 0;
  microTypeName = '';
}

export class ReleaseTypesOptionModel {
  releaseTypeCode = '';
  releaseTypeName = '';
}

export class ModuleNamesOptionsModel {
  moduleName = '';
}

export class MicroNamesOptionsModel {
  microName = '';
}
