export class CommonSblModel {
  moduleTypeCode = '';
  description = '';
  userId = '';
}

export class AddSblPostModel extends CommonSblModel {
  supplierCode = '';
  microTypeCode = 0;
  leadMyProgram = '';
}

export class ReplaceSblPutModel extends CommonSblModel {
  currentPartNumber = '';
}

export class SblModel {
  releaseType = 'new_sbl';
  supplierCode = '';
  supplierName = '';
  moduleTypeCode = '';
  moduleTypeName = '';
  microTypeCode = 0;
  microTypeName = '';
  description = '';
  leadMyProgram = '';
  currentPartNumber = '';
}
