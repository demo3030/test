export class FirmwareDescriptionModel {
  releaseType = '';
  moduleTypeCode = '';
  moduleTypeName = '';
}
