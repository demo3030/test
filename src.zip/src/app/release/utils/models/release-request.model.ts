export class ReleaseRequestGetModel {
  id = '';
  module = '';
  rLevel = '';
  status = '';
  owner = '';
  modelYear = '';
  program = '';
  engine = '';
  createUser = '';
  lastUpdateUser = '';
}

export class ReleaseRequestDetailModel {
  requestId = '';
  owner = '';
  status = '';
  moduleType = '';
  priority = '';
  priorityDriver = '';
  releaseConcernReason = '';
  firmwareProgram = '';
  calibrationRNumber = '';
  isCoordinationRequired = '';
  swStrategy = '';
  isBackwardCompatChange = '';
  buildEvent = '';
  calibrationReleaseDateCfx = '';
  projectControlEngineer = '';
  firmwareReleaseUsage = '';
  releaseTitle = '';
  isCalibrationCCMNumber = '';
  isAdditionalHwSwCoordRequired = '';
  hwSwCoordDetail = '';
  isAlertRequired = '';
  alertDetail = '';
  isRollingUsageRequired = '';
  rollingUsageChanges = '';
  buildStartDate = '';
  suppliertVbfDeliveryDate = '';
  appDREngineer = '';
  calibrationEngineer = '';
  calibrationReleaseSupport = '';
  hardwarePartNumber = '';
  ipfInstalledPartNumber = '';
  servicePartNumber = '';
}
