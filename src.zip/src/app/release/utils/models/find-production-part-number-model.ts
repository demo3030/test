export class FindProductionPartNumberModel {
  pnPre = '';
  pnBase = '';
  pnSuffix = '';
  wersNotice = '';
  catchWord = '';
  swpnPre = '';
  swpnBase = '';
  swpnSuffix = '';
  calibrationNumber = '';
  stratRelName = '';
  chipID = '';
}

export class FindProductionPartNumberPostModel {
  partNumber = '';
  wersNotice = '';
  catchWord = '';
  softwarePartNumber = '';
  calibrationNumber = '';
  stratRelName = '';
  chipID = '';
}

export interface ProductionPartNumberRecord {
  partNumber: string;
  catchWord: string;
  calibrationNumber: string;
  softwarePN: string;
  hardwarePN: string;
  mainMicroType: string;
  wersNotice: string;
}
