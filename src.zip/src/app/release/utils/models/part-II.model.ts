export class AddPartIIModel {
  releaseType = 'part_II';
  moduleTypeName = '';
  moduleTypeCode = '';
  microTypeCode = 0;
  microTypeName = '';
  ggdsVersion = '';
  swdlVersion = '';
  partNumber = '';
  description = '';
  uploadedToVSEM = '';
}

export class AddPartIIPdxPostModel {
  releaseType = '';
  moduleTypeCode = '';
  microTypeCode = 0;
  createUser = '';
  lastUpdateUser = '';
  ggdsVersion = '';
  swdlVersion = '';
  partNumber = '';
  description = '';
  uploadedToVSEM = '';
}
