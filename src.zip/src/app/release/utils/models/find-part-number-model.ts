export class FindPartNumberModel {
  releaseTypes: string[] = [];
  releaseUsage = '';
  assemblyPN = '';
  softwarePN = '';
  hardwarePN = '';
  applicationEngineer = '';
  catchWord = '';
  calibrationNumber = '';
  swMainStrategy = '';
  concernNumber = '';
  pnStatus = '';
  dateCreatedFrom = '';
  dateCreatedTo = '';
  dateReleasedFrom = '';
  dateReleasedTo = '';
}

export interface PartDetail {
  assemblyPN: string;
  hardwarePN: string;
  supplier: string;
  catchWord: string;
  calibrationNum: string;
  status: string;
  dateCreated: string;
}

export interface PartNumberRecord {
  concernNumber: string;
  parts: PartDetail[];
}
