export class AddPblData {
  newPbl = '';
  moduleTypeCode = '';
  createUser = '';
  lastUpdateUser = '';
}

export class FetchPartDetails {
  newPbl = '';
  currentPbl = '';
}

export class PartFirmware {
  firmwareN = '';
  fileN = '';
  aprvdByCdsidC = '';
  firmwareCatgN = '';
  aprvdY = '';
}

export class PartFirmwareRecord {
  assemblyPN = '';
  drcdsId = '';
  hardwarePN = '';
  coreHardwarePN = '';
  mainMicroType = '';
  programDescriptions: ProgramDescription[] = [];
  lineage = '';
  partFirmwares: PartFirmware[] = [];
}

export class ProgramDescription {
  pgmK = 0;
  mdlYrR = '';
  pgmN = '';
  platN = '';
  engN = '';
  transN = '';
}

export class ReplacePblPutModel {
  newPbl = '';
  moduleTypeCode = '';
  createUser = '';
  lastUpdateUser = '';
  partNumbers: string[] = [];
}

export class PblModel {
  releaseType = 'new_pbl';
  moduleTypeCode = '';
  moduleTypeName = '';
  currentPbl = '';
  newPbl = '';
}
