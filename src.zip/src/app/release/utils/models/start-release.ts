export class SetupReleaseModel {
    replacementParts: string = '';
    moduleType: string = '';
}