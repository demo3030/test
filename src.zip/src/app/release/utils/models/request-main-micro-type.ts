export class AddRequestMainMicroTypeModel {
  moduleTypeCode = '';
  moduleTypeName = '';
  supplierCode = '';
  supplierName = '';
  moduleFamily = '';
  moduleName = '';
  microName = '';
  mainMicroTypeName = '';
  internalFlashMemorySize = '';
  microNonPCMName = '';
}

export class AddPostRequestMainMicroTypeModel {
  mainMicroTypeName = '';
  createUser = '';
  lastUpdateUser = '';
  moduleTypeCode = '';
  supplierCode = '';
  supplierName = '';
}
