import {Component} from '@angular/core';

@Component({
  selector: 'app-prism-input',
  templateUrl: './prism-input.component.html',
  styleUrls: ['./prism-input.component.scss']
})
export class PrismInputComponent {}
