import {Component} from '@angular/core';

@Component({
  selector: 'app-coordinated-module-matrix',
  templateUrl: './coordinated-module-matrix.component.html',
  styleUrls: ['./coordinated-module-matrix.component.scss']
})
export class CoordinatedModuleMatrixComponent {}
