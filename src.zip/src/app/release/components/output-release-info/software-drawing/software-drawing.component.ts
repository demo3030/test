import {Component} from '@angular/core';

@Component({
  selector: 'app-software-drawing',
  templateUrl: './software-drawing.component.html',
  styleUrls: ['./software-drawing.component.scss']
})
export class SoftwareDrawingComponent {}
