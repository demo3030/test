import {Component} from '@angular/core';

@Component({
  selector: 'app-software-release-analyst',
  templateUrl: './software-release-analyst.component.html',
  styleUrls: ['./software-release-analyst.component.scss']
})
export class SoftwareReleaseAnalystComponent {}
