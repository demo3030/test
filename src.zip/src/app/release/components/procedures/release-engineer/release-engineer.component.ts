import {Component} from '@angular/core';

@Component({
  selector: 'app-release-engineer',
  templateUrl: './release-engineer.component.html',
  styleUrls: ['./release-engineer.component.scss']
})
export class ReleaseEngineerComponent {}
