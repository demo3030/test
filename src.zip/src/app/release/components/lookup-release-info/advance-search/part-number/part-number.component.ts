import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../../utils/services/release.service";
import {
  FindPartNumberModel,
  PartNumberRecord,
} from "../../../../utils/models/find-part-number-model";
import { Subject } from "rxjs";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { takeUntil } from "rxjs/operators";
import { HttpErrorResponse, HttpResponse } from "@angular/common/http";
import { ExportToXmlPostModel } from "../../../../utils/models/xml.model";
import { CheckboxChangeEvent } from "primeng/checkbox";

@Component({
  selector: "app-part-number",
  templateUrl: "./part-number.component.html",
  styleUrls: ["./part-number.component.scss"],
})
export class PartNumberComponent implements OnInit, OnDestroy {
  findPartNumberData: FindPartNumberModel = new FindPartNumberModel();
  selectedReleaseTypes: any[] = [];
  releaseTypes: any[] = [];
  releaseUsages: any[] = [];
  displayPartNumberResults: boolean = false;
  selectAllChecked: boolean = false;
  firmwareRecords: PartNumberRecord[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();
  selectedConcernNumber!: string;
  displayPartNumberPage: boolean = true;
  loading: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) { }

  ngOnInit() {
    this.resetState();
    this.getReleaseTypes();
    this.getReleaseUsages();
  }

  private resetState() {
    this.findPartNumberData = new FindPartNumberModel();
    this.selectedReleaseTypes = [];
    this.displayPartNumberResults = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
    this.loading = false;
  }

  displayFirmwareDetailsByConcerNumber(concerNumber: string) {
    this.displayPartNumberPage = false;
    this.selectedConcernNumber = concerNumber;
  }

  getReleaseTypes() {
    this.releaseService.getReleaseTypes().subscribe((res) => {
      if (res && res.length > 0) {
        this.releaseTypes = res.map((releaseType: any) => ({
          label: releaseType.releaseTypeName,
          value: releaseType.releaseTypeName
        }));       
      } else {
        console.error("Failed to fetch release types.");
        this.releaseTypes = [];
      }
    });
  }
  

  getReleaseUsages() {
    try {
      this.releaseService.getReleaseUsages().subscribe((res) => {
        if (res && res.length > 0) {

          this.releaseUsages = res.map(
            (releaseUsage: any) =>
            ({
              label: `${releaseUsage.releaseUsageName}`,
              value: `${releaseUsage.releaseUsageName}`
            })
          );
        } else {
          console.error(
            "Something went wrong while fetching the release usages."
          );
          this.releaseUsages = [];
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    console.log(assemblyPN);
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN);
    } else {
      this.selectedRecords.add(assemblyPN);
    }
  }

  areAllPartsSelected(record: PartNumberRecord): boolean {
    return record.parts.every((part) =>
      this.selectedRecords.has(part.assemblyPN)
    );
  }

  toggleSelectAllParts(record: PartNumberRecord, event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;

    record.parts.forEach((part) => {
      if (isChecked) {
        this.selectedRecords.add(part.assemblyPN);
      } else {
        this.selectedRecords.delete(part.assemblyPN);
      }
    });
  }

  toggleSelectAll(event: CheckboxChangeEvent) {
    const checked = event.checked;
    this.selectAllChecked = checked;

    if (checked) {
      this.firmwareRecords.forEach((record) => {
        record.parts.forEach((part) => {
          this.selectedRecords.add(part.assemblyPN);
        });
      });
    } else {
      this.selectedRecords.clear();
    }
  }

  onSearch() {
    console.log(this.findPartNumberData);
    if (this.validatePartNumberData()) {
      this.loading = true;
      this.releaseService
        .getFirmwareDetailsByPartNumber(this.findPartNumberData)
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe({
          next: (response: any) => {
            this.loading = false;
            this.displayPartNumberResults = true;
            this.firmwareRecords = Array.isArray(response) ? response : [];
            this.selectedRecords.clear();
          },
          error: (error: HttpErrorResponse) => {
            this.loading = false;
            this.handleError(error);
          },
        });
    }
  }

  validatePartNumberData() {
    let errorMessages = [];
    const { dateCreatedFrom, dateCreatedTo, dateReleasedFrom, dateReleasedTo } =
      this.findPartNumberData;

    const dateCreatedError = this.isDatesInvalid(
      dateCreatedFrom,
      dateCreatedTo
    );
    if (dateCreatedError) {
      errorMessages.push(dateCreatedError);
    }

    const dateReleasedError = this.isDatesInvalid(
      dateReleasedFrom,
      dateReleasedTo
    );
    if (dateReleasedError) {
      errorMessages.push(dateReleasedError);
    }

    if (errorMessages.length > 0) {
      const fullMessage =
        errorMessages.join("<br>") +
        "<br><br>Please correct the issues listed above and try again.";
      this.findPartNumberData = new FindPartNumberModel();
      ReleaseUtils.showErrorSweetAlert("Error", fullMessage);
      return false;
    }

    return true;
  }

  isDatesInvalid(from: string, to: string): string | null {
    const today = new Date().toISOString().split("T")[0];

    if (!from && !to) {
      return null;
    }

    if (!from || !to) {
      return "Date cannot be null. Please fill in both dates.";
    }

    if (to < from) {
      return "Date Created - Invalid Date Range (From date cannot be greater than the To date).";
    }

    if (from > today && to > today) {
      return "Both dates cannot be in the future. Please select valid dates.";
    }

    return null;
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  onCancelClick() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  searchRedirect() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["release/advanced-search"]);
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const exportToXmlData: ExportToXmlPostModel = new ExportToXmlPostModel();
    exportToXmlData.partNumbers = partNumbers;
    ReleaseUtils.exportToXML(this.releaseService, exportToXmlData);
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      Array.from(this.selectedRecords)
    );
  }
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  } 

}
