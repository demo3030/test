import { Component, OnDestroy, OnInit } from "@angular/core";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Router } from "@angular/router";
import {
  ReleaseRequestDetailModel,
  ReleaseRequestGetModel,
} from "../../../../utils/models/release-request.model";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
  selector: "app-release-request",
  templateUrl: "./release-request.component.html",
  styleUrls: ["./release-request.component.scss"],
})
export class ReleaseRequestComponent implements OnInit, OnDestroy {
  errorMessage: string = "";
  searchParams = {
    id: "",
    module: "",
    rLevel: "",
    status: "",
    owner: "",
    modelYear: "",
    program: "",
    engine: "",
  };
  statuses: string[] = [
    "New",
    "Project Control",
    "D&R Engineer",
    "Cal Release Engineer",
    "Complete",
  ];
  releaseRequestDetails: any[] = [];
  displayReleaseRequestDetail: boolean = false;
  private unsubscribe$ = new Subject<void>();
  releaseRequestDetail: ReleaseRequestDetailModel =
    new ReleaseRequestDetailModel();
  isRequestIdReadonly: boolean = true;
  loading: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) { }

  ngOnInit() {
    this.fetchReleaseRequestDetails();
    this.loading = false;
  }

  fetchReleaseRequestDetails() {
    this.releaseService.getReleaseRequestDetails().subscribe((data) => {
      this.releaseRequestDetails = data;
    });
  }

  onSubmit(id: string) {
    this.releaseService.getRequestDetailById(id).subscribe((data) => {
      this.displayReleaseRequestDetail = true;
      this.releaseRequestDetail = data;
    });
  }

  onSearch() {
    this.loading = true;
    const { id, module, rLevel, status, owner, modelYear, program, engine } =
      this.searchParams;

    const dataToSend: ReleaseRequestGetModel = {
      id,
      module,
      rLevel,
      status,
      owner,
      modelYear,
      program,
      engine,
      createUser: "DSADASH1",
      lastUpdateUser: "DSADASH1",
    };

    this.releaseService
      .getReleaseRequestSearchDetails(dataToSend)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          this.releaseRequestDetails = response;
        },
        error: (error: HttpErrorResponse) => {
          this.loading = false;
          this.handleError(error);
        },
      });
  }

  clearSearch() {
    this.searchParams = {
      id: "",
      module: "",
      rLevel: "",
      status: "",
      owner: "",
      modelYear: "",
      program: "",
      engine: "",
    };
    this.fetchReleaseRequestDetails();
  }

  exportToExcel() {
    const { id, module, rLevel, status, owner, modelYear, program, engine } =
      this.searchParams;

    const allEmpty =
      !module &&
      !rLevel &&
      !status &&
      !owner &&
      !modelYear &&
      !program &&
      !engine;

    const finalId = allEmpty ? "-1" : id;

    const dataToSend: ReleaseRequestGetModel = {
      id: finalId,
      module,
      rLevel,
      status,
      owner,
      modelYear,
      program,
      engine,
      createUser: "DSADASH1",
      lastUpdateUser: "DSADASH1",
    };

    this.releaseService
      .exportReleaseRequestDetailsToExcel(dataToSend)
      .subscribe(
        (response) => {
          const blob = new Blob([response], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          let filename = "ReleaseRequestSearchResult.xlsx";

          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        },
        (error) => {
          console.error("Error exporting parts to excel:", error);
        }
      );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Unfortunately, an error has occurred. Please check back later.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }
}
