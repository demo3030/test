import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ReleaseService } from '../../../../utils/services/release.service';
import { Subject } from 'rxjs';
import { ErrorResponse } from '../../../../utils/models/error-response.model';
import { ReleaseUtils } from '../../../../utils/ReleaseUtils';
import { takeUntil } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { ExportToXmlPostModel } from '../../../../utils/models/xml.model';
import { CheckboxChangeEvent } from 'primeng/checkbox';

@Component({
  selector: 'app-program',
  templateUrl: './program.component.html',
  styleUrls: ['./program.component.scss']
})
export class ProgramComponent implements OnInit, OnDestroy {
  selectedPrograms: any[] = [];
  programs: any[] = [];
  tempShowTable: boolean = false;
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();
  selectAllChecked: boolean = false;
  loading: boolean = false;

  constructor(
    private router: Router,
    private releaseService: ReleaseService
  ) { }

  ngOnInit() {
    this.resetState();
    this.fetchPrograms();
  }

  private resetState() {
    this.selectedPrograms = [];
    this.firmwareRecords = [];
    this.tempShowTable = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
    this.loading = false;
  }

  fetchPrograms() {
    this.releaseService.getPrograms().subscribe((data) => {
      this.programs = data.map((program) => ({
        label: `${program.mdlYrR}, ${program.pgmN}, ${program.platN}, ${program.engN}, ${program.transN}`,
        value: program.programKey
      }));
    });
  }


  onOkClick() {
    this.loading = true;
    this.releaseService
      .getFirmwareDetailsByPrograms(this.selectedPrograms)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => {
          this.loading = false;
          this.handleError(error);
        }
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      'Unfortunately, an error has occurred. Please check back later.';

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === 'string') {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error('Error parsing response');
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    ReleaseUtils.showErrorSweetAlert('Error', errorMessage);
  }

  onCancelClick() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.router.navigate(['/']);
  }

  toggleSelectAll(event: CheckboxChangeEvent) {
    const isChecked = event.checked;
    this.selectAllChecked = isChecked;
    this.selectedRecords.clear();

    if (isChecked) {
      this.firmwareRecords.forEach((record) => {
        record.selected = true;
        this.selectedRecords.add(record.assemblyPN);

      });
    } else {
      this.firmwareRecords.forEach((record) => {
        record.selected = false;
        this.selectedRecords.add(record.assemblyPN);

      });
    }
  }

  toggleRecordSelection(assemblyPN: string) {
    const record = this.firmwareRecords
      .flatMap((group) => group.firmwares)
      .find((r) => r.assemblyPN === assemblyPN);
    if (record) {
      if (record.selected) {
        this.selectedRecords.add(assemblyPN);
      } else {
        this.selectedRecords.delete(assemblyPN);
      }
    }
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const exportToXmlData: ExportToXmlPostModel = new ExportToXmlPostModel();
    exportToXmlData.partNumbers = partNumbers;
    ReleaseUtils.exportToXML(this.releaseService, exportToXmlData);
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      Array.from(this.selectedRecords)
    );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
