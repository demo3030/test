import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {ReleaseService} from 'src/app/release/utils/services/release.service';
import {ReleaseUtils} from '../../../utils/ReleaseUtils';
import {ErrorResponse} from '../../../utils/models/error-response.model';
import Swal from 'sweetalert2';
import {
  AddSblPostModel,
  ReplaceSblPutModel
} from '../../../utils/models/sbl.model';

@Component({
  selector: 'app-add-sbl',
  templateUrl: './add-sbl.component.html',
  styleUrls: ['./add-sbl.component.scss']
})
export class AddSblComponent implements OnInit {
  form!: FormGroup;
  submitted = false;

  releaseTypeOptions = [
    {label: 'New SBL', value: 'new_sbl'},
    {label: 'Replace SBL (Backward Compatible)', value: 'replace_sbl'}
  ];

  supplierOptions = [];
  moduleTypeOptions = [];
  microTypeOptions = [];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      releaseType: ['new_sbl', Validators.required],
      supplier: ['', Validators.required],
      moduleType: ['', Validators.required],
      microType: ['', Validators.required],
      leadMyProgram: ['', Validators.required],
      description: ['', ''],
      currentPartNumber: ['', '']
    });

    this.getSupplierData();
    this.getModuleTypes();

    this.form.get('releaseType')?.valueChanges.subscribe((releaseType) => {
      this.resetFormFields();
      if (releaseType === 'replace_sbl') {
        this.addRemoveFieldsForReplaceSBL();
      } else {
        this.addRemoveFieldsForNewSBL();
      }
    });

    this.form
      .get('moduleType')
      ?.valueChanges.subscribe((selectedModuleType) => {
        if (this.form.value.releaseType === 'new_sbl' && selectedModuleType) {
          this.getMicroTypes(selectedModuleType);
        }
      });
  }

  resetFormFields(): void {
    const releaseTypeValue = this.form.get('releaseType')?.value;
    if (releaseTypeValue === 'replace_sbl') {
      this.form.get('currentPartNumber')?.reset();
    } else {
      this.form.get('supplier')?.reset();
      this.form.get('microType')?.reset();
      this.form.get('leadMyProgram')?.reset();
    }
    this.form.get('moduleType')?.reset();
    this.form.get('description')?.reset();
  }

  currentPartNumberValidator() {
    return (control: any) => {
      const currentPartNumber = control.value;

      if (!ReleaseUtils.isPartNumber(currentPartNumber)) {
        return {invalidFormat: {message: 'Current Part Number Required.'}};
      }

      const basePartNumberError = ReleaseUtils.validateSblBasePartNumber(
        this.form.value.moduleType,
        currentPartNumber
      );

      if (basePartNumberError) {
        return {invalidFormat: {message: basePartNumberError}};
      }

      console.log('Part Number Validated Successfully');
      return null;
    };
  }

  addRemoveFieldsForReplaceSBL() {
    if (!this.form.contains('currentPartNumber')) {
      this.form.addControl(
        'currentPartNumber',
        this.fb.control('', [
          Validators.required,
          this.currentPartNumberValidator()
        ])
      );
    } else {
      this.form
        .get('currentPartNumber')
        ?.setValidators([
          Validators.required,
          this.currentPartNumberValidator()
        ]);
    }
    this.form.get('currentPartNumber')?.updateValueAndValidity();

    if (this.form.contains('supplier')) {
      this.form.removeControl('supplier');
    }
    if (this.form.contains('microType')) {
      this.form.removeControl('microType');
    }
    if (this.form.contains('leadMyProgram')) {
      this.form.removeControl('leadMyProgram');
    }

    this.form.get('supplier')?.clearValidators();
    this.form.get('supplier')?.updateValueAndValidity();
    this.form.get('microType')?.clearValidators();
    this.form.get('microType')?.updateValueAndValidity();
    this.form.get('leadMyProgram')?.clearValidators();
    this.form.get('leadMyProgram')?.updateValueAndValidity();
  }

  addRemoveFieldsForNewSBL() {
    if (!this.form.contains('supplier')) {
      this.form.addControl(
        'supplier',
        this.fb.control('', Validators.required)
      );
    }
    if (!this.form.contains('microType')) {
      this.form.addControl(
        'microType',
        this.fb.control('', Validators.required)
      );
    }
    if (!this.form.contains('leadMyProgram')) {
      this.form.addControl(
        'leadMyProgram',
        this.fb.control('', Validators.required)
      );
    }

    if (this.form.contains('currentPartNumber')) {
      this.form.removeControl('currentPartNumber');
    }

    this.form.get('currentPartNumber')?.clearValidators();
    this.form.get('currentPartNumber')?.updateValueAndValidity();
  }

  getSupplierData() {
    try {
      this.releaseService.getSupplier().subscribe((res) => {
        if (res.length > 0) {
          this.supplierOptions = res.map((supplier: any) => ({
            label: supplier.supplierName,
            value: supplier.supplierCode
          }));
        } else {
          console.error('Something went wrong while fetching the suppliers.');
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res.map((moduleType: any) => ({
            label: moduleType.moduleTypeName,
            value: moduleType.moduleTypeCode
          }));
        } else {
          console.error(
            'Something went wrong while fetching the module types.'
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getMicroTypes(moduleTypeCode: string) {
    try {
      this.releaseService.getMicroTypes(moduleTypeCode).subscribe((res) => {
        if (res.length > 0) {
          this.microTypeOptions = res.map((microType: any) => ({
            label: microType.microTypeName,
            value: microType.microTypeCode
          }));
        } else {
          console.error('Something went wrong while fetching the micro types.');
          this.microTypeOptions = [];
        }
      });
    } catch (err) {
      console.error(err);
      this.microTypeOptions = [];
    }
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!(
      control &&
      control.invalid &&
      (control.touched || control.dirty || this.submitted)
    );
  }

  getErrorMessage(controlName: string): string {
    const control = this.form.get(controlName);
    if (control && control.errors) {
      if (control.errors['invalidFormat']) {
        return control.errors['invalidFormat'].message;
      }
    }
    return '';
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.valid) {
      const formValues = this.form.value;
      const releaseType = formValues.releaseType;
      if (releaseType === 'new_sbl') {
        const moduleTypeCode = formValues.moduleType;
        const microTypeCode = formValues.microType;
        const supplierCode = formValues.supplier;
        const leadMyProgram = formValues.leadMyProgram;
        const description = formValues.description;

        const dataToSend: AddSblPostModel = {
          supplierCode,
          moduleTypeCode,
          microTypeCode,
          description,
          leadMyProgram,
          userId: 'DSADASH1'
        };
        this.addNewSBL(dataToSend);
      } else if (releaseType === 'replace_sbl') {
        const moduleTypeCode = formValues.moduleType;
        const description = formValues.description;
        const currentPartNumber = formValues.currentPartNumber;
        const dataToSend: ReplaceSblPutModel = {
          moduleTypeCode,
          description,
          currentPartNumber,
          userId: 'DSADASH1'
        };
        this.replaceNewSBL(dataToSend);
      }
    } else {
      this.form.markAllAsTouched();
    }
  }

  onCancel(): void {
    this.submitted = false;
    this.form.reset();
    window.scrollTo({top: 0, behavior: 'smooth'});
    this.router.navigate(['/']);
  }

  addNewSBL(sblData: AddSblPostModel) {
    this.releaseService.addSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';
        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }

  replaceNewSBL(sblData: ReplaceSblPutModel) {
    this.releaseService.replaceSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';
        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }
}
