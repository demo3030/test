import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {ReleaseService} from 'src/app/release/utils/services/release.service';
import {ReleaseUtils} from '../../../utils/ReleaseUtils';
import {ErrorResponse} from '../../../utils/models/error-response.model';
import Swal from 'sweetalert2';
import {
  AddPblData,
  FetchPartDetails,
  ReplacePblPutModel
} from '../../../utils/models/pbl.model';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-add-pbl',
  templateUrl: './add-pbl.component.html',
  styleUrls: ['./add-pbl.component.scss']
})
export class AddPblComponent implements OnInit {
  form!: FormGroup;
  submitted = false;
  displayFirmDetails = false;
  firmwareRecords: any[] = [];
  selectedRecords = new Set<string>();
  releaseTypeOptions = [
    {label: 'New PBL', value: 'new_pbl'},
    {label: 'Replace PBL (Backward Compatible)', value: 'replace_pbl'}
  ];

  moduleTypeOptions = [];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      releaseType: ['new_pbl', Validators.required],
      moduleType: ['', Validators.required],
      currentPbl: ['', ''],
      newPbl: ['', Validators.required]
    });
    this.getModuleTypes();

    this.form.get('releaseType')?.valueChanges.subscribe((releaseType) => {
      this.resetFormFields();
      if (releaseType === 'replace_pbl') {
        this.addRemoveFieldsForReplacePBL();
      } else {
        this.addRemoveFieldsForNewPBL();
      }
    });
  }

  resetFormFields(): void {
    const releaseTypeValue = this.form.get('releaseType')?.value;
    if (releaseTypeValue === 'replace_pbl') {
      this.form.get('currentPbl')?.reset();
    }
    this.form.get('moduleType')?.reset();
    this.form.get('newPbl')?.reset();
  }

  addRemoveFieldsForReplacePBL() {
    if (!this.form.contains('currentPbl')) {
      this.form.addControl(
        'currentPbl',
        this.fb.control('', [Validators.required])
      );
    } else {
      this.form.get('currentPbl')?.setValidators([Validators.required]);
    }
    this.form.get('currentPbl')?.updateValueAndValidity();
  }

  addRemoveFieldsForNewPBL() {
    if (this.form.contains('currentPbl')) {
      this.form.removeControl('currentPbl');
    }

    this.form.get('currentPbl')?.clearValidators();
    this.form.get('currentPbl')?.updateValueAndValidity();
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!(
      control &&
      control.invalid &&
      (control.touched || control.dirty || this.submitted)
    );
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res.map((moduleType: any) => ({
            label: moduleType.moduleTypeName,
            value: moduleType.moduleTypeCode
          }));
        } else {
          console.error(
            'Something went wrong while fetching the module types.'
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.valid) {
      const formValues = this.form.value;
      const releaseType = formValues.releaseType;
      if (releaseType === 'new_pbl') {
        const moduleTypeCode = formValues.moduleType;
        const newPbl = formValues.newPbl;
        const dataToSend: AddPblData = {
          newPbl,
          moduleTypeCode,
          createUser: 'DSADASH1',
          lastUpdateUser: 'DSADASH1'
        };
        this.addNewPBL(dataToSend);
      } else if (releaseType === 'replace_pbl') {
        const currentPbl = formValues.currentPbl;
        const newPbl = formValues.newPbl;
        const dataToSend: FetchPartDetails = {
          newPbl,
          currentPbl
        };
        this.fetchPartsByFirmware(dataToSend);
      }
    }
  }

  onCancel(): void {
    this.submitted = false;
    this.form.reset();
    window.scrollTo({top: 0, behavior: 'smooth'});
    this.router.navigate(['/']);
  }

  addNewPBL(pblData: AddPblData) {
    this.releaseService.addPBL(pblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';

        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }

  fetchPartsByFirmware(firmwareData: FetchPartDetails) {
    this.releaseService.getPartsByFirmware(firmwareData).subscribe({
      next: (response: any) => {
        this.displayFirmDetails = true;
        this.firmwareRecords = Array.isArray(response) ? response : [];
      },
      error: (error: HttpErrorResponse) => {
        let errorMessage =
          'Unfortunately, an error has occurred. Please check back later.';

        if (error.error instanceof ErrorEvent) {
          errorMessage = error.error.message;
        } else if (error.error && typeof error.error === 'string') {
          try {
            const errorResponse: ErrorResponse = JSON.parse(error.error);
            errorMessage = errorResponse.message || errorMessage;
          } catch (e) {
            console.error('Error parsing response:', e);
          }
        } else if (error.error && error.error.message) {
          errorMessage = error.error.message;
        }

        ReleaseUtils.showErrorSweetAlert('Error', errorMessage);
      }
    });
  }

  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    if (isChecked) {
      this.firmwareRecords.forEach((record) => {
        this.selectedRecords.add(record.assemblyPN);
      });
    } else {
      this.selectedRecords.clear();
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN);
    } else {
      this.selectedRecords.add(assemblyPN);
    }
  }

  replacePBL() {
    const formValues = this.form.value;
    const moduleTypeCode = formValues.moduleType;
    const newPbl = formValues.newPbl;

    const dataToSend: ReplacePblPutModel = {
      newPbl,
      moduleTypeCode,
      createUser: 'DSADASH1',
      lastUpdateUser: 'DSADASH1',
      partNumbers: Array.from(this.selectedRecords)
    };
    this.releaseService.replacePBL(dataToSend).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';

        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }

  exportToExcel() {
    ReleaseUtils.exportToExcel(
      this.releaseService,
      this.firmwareRecords.map((record) => record.assemblyPN)
    );
  }

  cancelSubmit() {
    this.form.reset();
    window.scrollTo({top: 0, behavior: 'smooth'});
    this.router.navigate(['/']);
  }
}
