import {Component, OnInit} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
  ValidatorFn
} from '@angular/forms';
import {Router} from '@angular/router';
import {ReleaseService} from 'src/app/release/utils/services/release.service';
import {ReleaseUtils} from '../../../utils/ReleaseUtils';
import {ErrorResponse} from '../../../utils/models/error-response.model';
import Swal from 'sweetalert2';
import {
  AddSblPostModel,
  ReplaceSblPutModel
} from '../../../utils/models/sbl.model';
import {AddPartIIPdxPostModel} from 'src/app/release/utils/models/part-II.model';

@Component({
  selector: 'app-add-new-part-ii-or-pdx',
  templateUrl: './add-new-part-ii-or-pdx.component.html',
  styleUrls: ['./add-new-part-ii-or-pdx.component.scss']
})
export class AddNewPartIiOrPdxComponent implements OnInit {
  form!: FormGroup;
  submitted = false;

  releaseTypeOptions = [
    {label: 'Part II', value: 'PII'},
    {label: 'PDX', value: 'PDX'}
  ];

  uploadedToVSEMOptions = [
    {label: 'Yes', value: 'Y'},
    {label: 'No', value: 'N'}
  ];

  moduleTypeOptions = [];
  microTypeOptions = [];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      releaseType: ['PII', Validators.required],
      moduleType: ['', Validators.required],
      microType: ['', Validators.required],
      ggdsVersion: ['', Validators.required],
      swdlVersion: ['', Validators.required],
      partNumber: ['', [Validators.required, this.partNumberValidator()]],
      description: ['', ''],
      uploadedToVSEM: ['', Validators.required]
    });

    this.getModuleTypes();

    this.form.get('releaseType')?.valueChanges.subscribe(() => {
      this.resetFormFields();
    });

    this.form
      .get('moduleType')
      ?.valueChanges.subscribe((selectedModuleType) => {
        if (selectedModuleType) {
          this.getMicroTypes(selectedModuleType);
        }
      });
  }

  resetFormFields(): void {
    const releaseTypeValue = this.form.get('releaseType')?.value;
    if (releaseTypeValue) {
      this.form.get('moduleType')?.reset();
      this.form.get('microType')?.reset();
      this.form.get('ggdsVersion')?.reset();
      this.form.get('swdlVersion')?.reset();
      this.form.get('partNumber')?.reset();
      this.form.get('description')?.reset();
      this.form.get('uploadedToVSEM')?.reset();
    }
  }

  partNumberValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const releaseType = this.form && this.form.get('releaseType')?.value;
      const moduleTypeCode = this.form && this.form.get('moduleType')?.value;
      if (!releaseType || !moduleTypeCode) {
        return null;
      }
      const partNumber = control.value;

      if (ReleaseUtils.TestPartNumber(partNumber, releaseType) === false) {
        if (releaseType === 'PDX') {
          return {
            invalidFormat: {
              message: `'${partNumber}' is not a valid part number. Must start with PX.`
            }
          };
        } else {
          return {
            invalidFormat: {
              message: `'${partNumber}' is not a valid part number. Must start with DS.`
            }
          };
        }
      } else {
        const basePartValidationResult =
          ReleaseUtils.ValidateAssemblyBasePartNumberFromModuleType(
            moduleTypeCode,
            partNumber
          );
        if (basePartValidationResult) {
          return {invalidFormat: {message: basePartValidationResult}};
        }
      }

      return null;
    };
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res.map((moduleType: any) => ({
            label: moduleType.moduleTypeName,
            value: moduleType.moduleTypeCode
          }));
        } else {
          console.error(
            'Something went wrong while fetching the module types.'
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getMicroTypes(moduleTypeCode: string) {
    try {
      this.releaseService.getMicroTypes(moduleTypeCode).subscribe((res) => {
        if (res.length > 0) {
          this.microTypeOptions = res.map((microType: any) => ({
            label: microType.microTypeName,
            value: microType.microTypeCode
          }));
        } else {
          console.error('Something went wrong while fetching the micro types.');
          this.microTypeOptions = [];
        }
      });
    } catch (err) {
      console.error(err);
      this.microTypeOptions = [];
    }
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!(
      control &&
      control.invalid &&
      (control.touched || control.dirty || this.submitted)
    );
  }

  getErrorMessage(controlName: string): string {
    const control = this.form.get(controlName);
    if (control && control.errors) {
      if (control.errors['invalidFormat']) {
        return control.errors['invalidFormat'].message;
      }
    }
    return '';
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.valid) {
      const formValues = this.form.value;
      const releaseType = formValues.releaseType;
      const moduleTypeCode = formValues.moduleType;
      const microTypeCode = formValues.microType;
      const ggdsVersion = formValues.ggdsVersion;
      const swdlVersion = formValues.swdlVersion;
      const partNumber = formValues.partNumber;
      const description = formValues.description;
      const uploadedToVSEM = formValues.uploadedToVSEM;

      const dataToSend: AddPartIIPdxPostModel = {
        releaseType,
        microTypeCode,
        moduleTypeCode,
        ggdsVersion,
        swdlVersion,
        partNumber,
        createUser: 'DSADASH1',
        lastUpdateUser: 'DSADASH1',
        description,
        uploadedToVSEM
      };

      this.releaseService.addPartIIPDX(dataToSend).subscribe({
        next: (response: any) => {
          const successMessage = response;
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: successMessage,
            confirmButtonColor: '#00467f'
          }).then(() => {
            this.router.navigate(['/']);
          });
        },
        error: (error: any) => {
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch {
            errorResponse = {
              status: 'error',
              message:
                'Unfortunately, an error has occurred. Please check back later.'
            };
          }

          const errorMessage =
            errorResponse.message ||
            'Unfortunately, an error has occurred. Please check back later.';
          ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
        }
      });
    } else {
      this.form.markAllAsTouched();
    }
  }

  onCancel(): void {
    this.submitted = false;
    this.form.reset();
    window.scrollTo({top: 0, behavior: 'smooth'});
    this.router.navigate(['/']);
  }

  addNewSBL(sblData: AddSblPostModel) {
    this.releaseService.addSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';
        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }

  replaceNewSBL(sblData: ReplaceSblPutModel) {
    this.releaseService.replaceSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: successMessage,
          confirmButtonColor: '#00467f'
        }).then(() => {
          this.router.navigate(['/']);
        });
      },
      error: (error: any) => {
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch {
          errorResponse = {
            status: 'error',
            message:
              'Unfortunately, an error has occurred. Please check back later.'
          };
        }

        const errorMessage =
          errorResponse.message ||
          'Unfortunately, an error has occurred. Please check back later.';
        ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
      }
    });
  }
}
