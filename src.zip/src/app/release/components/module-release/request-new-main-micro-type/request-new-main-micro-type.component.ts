import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {ReleaseService} from 'src/app/release/utils/services/release.service';
import {ReleaseUtils} from '../../../utils/ReleaseUtils';
import {ErrorResponse} from '../../../utils/models/error-response.model';
import Swal from 'sweetalert2';
import {AddPostRequestMainMicroTypeModel} from 'src/app/release/utils/models/request-main-micro-type';

@Component({
  selector: 'app-request-new-main-micro-type',
  templateUrl: './request-new-main-micro-type.component.html',
  styleUrls: ['./request-new-main-micro-type.component.scss']
})
export class RequestNewMainMicroTypeComponent implements OnInit {
  form!: FormGroup;
  submitted = false;

  isPCMVisible = false;
  internalFlashMemoryVisible = false;
  externalFlashMemoryVisible = false;
  moduleFamilyVisible = false;
  microNonPCMNameVisible = false;

  supplierOptions = [];
  moduleTypeOptions = [];
  moduleNameOptions: {label: string; value: string}[] = [];
  microNameOptions: {label: string; value: string}[] = [];

  unitOptions = [
    {label: 'MB', value: 'MB'},
    {label: 'KB', value: 'KB'}
  ];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      supplier: ['', Validators.required],
      moduleType: ['', Validators.required],
      moduleFamily: ['', ''],
      microPCMName: ['', ''],
      moduleName: ['', ''],
      microNonPCMName: ['', ''],
      internalFlashMemorySize: ['', ''],
      externalFlashMemorySize: ['', ''],
      internalFlashMemorySizeUnit: ['', ''],
      externalFlashMemorySizeUnit: ['', ''],
      mainMicroTypeName: ['', Validators.required]
    });

    this.form.valueChanges.subscribe(() => this.buildNewMainMicroTypeName());

    this.getSupplierData();
    this.getModuleTypes();
    this.getModuleNames();
    this.getMicroNames();
  }

  getModuleNames() {
    this.releaseService.getModuleNames().subscribe(
      (res: string[]) => {
        if (res.length > 0) {
          this.moduleNameOptions = res.map((name) => ({
            label: name,
            value: name
          }));
        } else {
          console.error(
            'Something went wrong while fetching the module names.'
          );
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  getMicroNames() {
    this.releaseService.getMicroNames().subscribe(
      (res: string[]) => {
        if (res.length > 0) {
          this.microNameOptions = res.map((name) => ({
            label: name,
            value: name
          }));
        } else {
          console.error('Something went wrong while fetching the micro names.');
        }
      },
      (error) => {
        console.error(error);
      }
    );
  }

  getSupplierData() {
    try {
      this.releaseService.getSupplier().subscribe((res) => {
        if (res.length > 0) {
          this.supplierOptions = res.map((supplier: any) => ({
            label: supplier.supplierName,
            value: supplier.supplierCode
          }));
        } else {
          console.error('Something went wrong while fetching the suppliers.');
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res.map((moduleType: any) => ({
            label: moduleType.moduleTypeName,
            value: moduleType.moduleTypeCode
          }));
        } else {
          console.error(
            'Something went wrong while fetching the module types.'
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  onModuleTypeChange(event: any) {
    const moduleTypeName = event.value;
    this.handleModuleType(moduleTypeName);
  }

  handleModuleType(moduleTypeName: string) {
    this.isPCMVisible = moduleTypeName === 'PCM' || moduleTypeName === 'VCM';
    this.internalFlashMemoryVisible = !this.isPCMVisible && !!moduleTypeName;
    this.externalFlashMemoryVisible = !this.isPCMVisible && !!moduleTypeName;
    this.moduleFamilyVisible = !this.isPCMVisible && !!moduleTypeName;
    this.microNonPCMNameVisible = !this.isPCMVisible && !!moduleTypeName;
    this.buildNewMainMicroTypeName();
  }

  buildNewMainMicroTypeName() {
    let sName = '';
    const moduleTypeName = this.form.get('moduleType')?.value;
    const moduleName = this.form.get('moduleName')?.value;
    const microPCMName = this.form.get('microPCMName')?.value;
    const moduleFamily = this.form.get('moduleFamily')?.value;
    const microNonPCMName = this.form.get('microNonPCMName')?.value;
    const internalFlashMemorySize = this.form.get(
      'internalFlashMemorySize'
    )?.value;
    const externalFlashMemorySize = this.form.get(
      'externalFlashMemorySize'
    )?.value;
    const internalFlashMemorySizeUnit = this.form.get(
      'internalFlashMemorySizeUnit'
    )?.value;
    const externalFlashMemorySizeUnit = this.form.get(
      'externalFlashMemorySizeUnit'
    )?.value;

    let mainMicroTypeName = this.form.get('mainMicroTypeName')?.value;
    sName += this.form.get('supplier')?.value?.charAt(0).toUpperCase() + '_';

    if (moduleTypeName === 'PCM' || moduleTypeName === 'VCM') {
      sName += `${moduleName}_`;
      sName += `${microPCMName}_IB`;
    } else {
      if (!moduleTypeName || internalFlashMemorySize === '') {
        mainMicroTypeName = '';
        return;
      }
      sName += `${moduleFamily}_`;
      sName += `${microNonPCMName}_`;
      sName += `${internalFlashMemorySize}${internalFlashMemorySizeUnit}I`;

      if (
        externalFlashMemorySize !== '' &&
        externalFlashMemorySizeUnit !== '-NA-'
      ) {
        sName += `_${externalFlashMemorySize}${externalFlashMemorySizeUnit}E`;
      }
      sName += '_IB';
    }
    mainMicroTypeName = sName.toUpperCase();
    this.form
      .get('mainMicroTypeName')
      ?.setValue(mainMicroTypeName, {emitEvent: false});
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!(
      control &&
      control.invalid &&
      (control.touched || control.dirty || this.submitted)
    );
  }

  getErrorMessage(controlName: string): string {
    const control = this.form.get(controlName);
    if (control && control.errors) {
      if (control.errors['invalidFormat']) {
        return control.errors['invalidFormat'].message;
      }
    }
    return '';
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.valid) {
      const formValues = this.form.value;

      const moduleTypeCode = formValues.moduleType;
      const mainMicroTypeName = formValues.mainMicroTypeName;
      const supplierCode = formValues.supplier;
      const supplierName = formValues.supplier;

      const dataToSend: AddPostRequestMainMicroTypeModel = {
        mainMicroTypeName,
        createUser: 'DSADASH1',
        lastUpdateUser: 'DSADASH1',
        moduleTypeCode,
        supplierCode,
        supplierName
      };

      this.releaseService.addNewMainMicroType(dataToSend).subscribe({
        next: (response: any) => {
          const successMessage = response;
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: successMessage,
            confirmButtonColor: '#00467f'
          }).then(() => {
            this.router.navigate(['/']);
          });
        },
        error: (error: any) => {
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch {
            errorResponse = {
              status: 'error',
              message:
                'Unfortunately, an error has occurred. Please check back later.'
            };
          }

          const errorMessage =
            errorResponse.message ||
            'Unfortunately, an error has occurred. Please check back later.';
          ReleaseUtils.showErrorSweetAlert('Error', `${errorMessage}`);
        }
      });
    } else {
      this.form.markAllAsTouched();
    }
  }

  onCancel(): void {
    this.submitted = false;
    this.form.reset();
    window.scrollTo({top: 0, behavior: 'smooth'});
    this.router.navigate(['/']);
  }
}
