import {Component, OnInit, OnDestroy} from '@angular/core';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {ReleaseService} from 'src/app/release/utils/services/release.service';
import {Subject, takeUntil} from 'rxjs';
import {
  FedebomPlaceholderReleasePartRequest,
  FedebomReleaseModel
} from 'src/app/release/utils/models/fedebom-placeholder-release.model';
import {HttpErrorResponse} from '@angular/common/http';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-fedebom-placeholder-release',
  templateUrl: './fedebom-placeholder-release.component.html',
  styleUrls: ['./fedebom-placeholder-release.component.scss']
})
export class FedebomPlaceholderReleaseComponent implements OnInit, OnDestroy {
  form!: FormGroup;
  releaseType!: string;
  private unsubscribe$ = new Subject<void>();
  fedebomReleaseData: FedebomReleaseModel = new FedebomReleaseModel();
  loading = false;
  displayReleaseType = false;
  submitted = false;

  releaseTypeOptions = [
    {value: 'AREUL', label: 'PCM Assembly - EU/APA Legacy'},
    {value: 'AFG', label: 'PCM Assembly - FGEC'},
    {value: 'AFGO', label: 'PCM Assembly - Ford App Signing'},
    {value: 'AFD', label: 'PCM Assembly - FDEC'},
    {value: 'AFDCX', label: 'PCM Assembly - FDEC CFX'},
    {value: 'UTCU2', label: 'TCM Assembly - UTCU'}
  ];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit(): void {
    this.releaseType = 'AREUL';
    this.form = this.fb.group({
      releaseType: ['', Validators.required],
      commentToSRA: ['', Validators.required],
      parts: this.fb.array([]) // FormArray to manage dynamic parts
    });
  }

  get parts() {
    return this.form.get('parts') as FormArray;
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!(
      control &&
      control.invalid &&
      (control.touched || control.dirty || this.submitted)
    );
  }

  onNext(): void {
    const releaseTypeCode = this.releaseType;
    const releaseTypeOption = this.releaseTypeOptions.find(
      (option) => option.value === releaseTypeCode
    );
    this.loading = true;

    this.fedebomReleaseData.releaseTypeCode = releaseTypeCode;
    this.fedebomReleaseData.releaseTypeName = releaseTypeOption
      ? releaseTypeOption.label
      : '';
    this.fedebomReleaseData.moduleTypeCode =
      this.fetchModuleTypeCode(releaseTypeCode);

    this.fetchHardwarePartNumbers();
  }

  fetchModuleTypeCode(mReleaseTypeCode: string): string {
    let mModuleTypeCode: string;
    switch (mReleaseTypeCode) {
      case 'AREUL':
      case 'AFD':
      case 'AFDCX':
      case 'AFG':
      case 'AFGO':
        mModuleTypeCode = 'PCM';
        break;
      case 'UTCU2':
        mModuleTypeCode = 'TCM';
        break;
      default:
        mModuleTypeCode = 'PCM';
    }
    return mModuleTypeCode;
  }

  fetchHardwarePartNumbers() {
    const releaseTypeCode = this.fedebomReleaseData.releaseTypeCode || '';
    const moduleTypeCode = this.fedebomReleaseData.moduleTypeCode || '';

    this.releaseService
      .getHardwarePartNumbersByReleaseTypeAndModuleType(
        releaseTypeCode,
        moduleTypeCode
      )
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          if (response && Array.isArray(response)) {
            this.fedebomReleaseData.hardwarePartNumbers = response;
            this.adjustPartsArray();
          } else {
            Swal.fire('Error', 'Invalid response from the server.', 'error');
          }
          this.loading = false;
          this.displayReleaseType = true;
        },
        error: (error: HttpErrorResponse) => {
          this.loading = false;
          this.handleError(error);
        }
      });
  }

  adjustPartsArray(): void {
    const partsArray = this.parts;
    if (
      this.fedebomReleaseData.hardwarePartNumbers &&
      this.fedebomReleaseData.hardwarePartNumbers.length > 0
    ) {
      this.fedebomReleaseData.hardwarePartNumbers.forEach(() => {
        partsArray.push(
          this.fb.group({
            pnPrefix: ['', Validators.required],
            hardwarePn: [null, Validators.required]
          })
        );
      });
    }
  }

  getPartOptions() {
    return this.fedebomReleaseData.hardwarePartNumbers.map((part) => ({
      label: part,
      value: part
    }));
  }

  handleError(error: HttpErrorResponse) {
    let errorMessage =
      'Something went wrong while fetching the hardware part numbers.';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === 'string') {
      try {
        const errorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error('Error parsing response');
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    Swal.fire('Error', errorMessage, 'error');
  }

  onSubmitPartRequest() {
    const releaseTypeCode = this.fedebomReleaseData.releaseTypeCode || '';
    const moduleTypeCode = this.fedebomReleaseData.moduleTypeCode || '';
    const sraComment = this.form.get('commentToSRA')?.value || '';
    const userId = 'DSADASH1';

    if (
      !releaseTypeCode ||
      !moduleTypeCode ||
      !sraComment ||
      !this.parts?.value ||
      this.parts?.value.length === 0
    ) {
      Swal.fire({
        icon: 'error',
        title: 'Validation Error',
        text: 'Please make sure all required fields are filled and parts are provided.',
        confirmButtonColor: '#00467f'
      });
      return;
    }

    const parts =
      this.parts?.value
        .filter(
          (part: any) =>
            part.pnPrefix?.trim() !== '' && part.hardwarePn?.trim() !== ''
        )
        .map((part: any) => ({
          pnPrefix: part.pnPrefix,
          hardwarePn: part.hardwarePn
        })) || [];

    if (parts.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Validation Error',
        text: "Please make sure at least one part has both 'pnPrefix' and 'hardwarePn'.",
        confirmButtonColor: '#00467f'
      });
      return;
    }

    const requestData: FedebomPlaceholderReleasePartRequest = {
      moduleTypeCode: moduleTypeCode,
      releaseTypeCode: releaseTypeCode,
      userId: userId,
      sraComment: sraComment,
      fedebomPlaceholderReleaseParts: parts
    };

    this.loading = true;
    this.releaseService
      .addFedebomPlaceholderReleaseParts(requestData)
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: response,
            confirmButtonColor: '#00467f'
          }).then(() => {
            this.router.navigate(['/']);
          });
        },
        error: (error: any) => {
          this.loading = false;
          this.handleError(error);
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
