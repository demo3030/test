import { Component, OnDestroy, OnInit } from "@angular/core";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Router } from "@angular/router";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";

@Component({
  selector: "app-display-hard-lock-signoff",
  templateUrl: "./display-hard-lock-signoff.component.html",
  styleUrls: ["./display-hard-lock-signoff.component.scss"],
})
export class DisplayHardLockSignoffComponent implements OnInit, OnDestroy {
  hardLockSignoffDetails: any = {};
  userId: string = "DSADASH1";

  loading: boolean = false;
  private unsubscribe$ = new Subject<void>();

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.loadHardLockSignoffDetails();
  }

  loadHardLockSignoffDetails() {
    this.loading = true;
    this.releaseService
      .getHardLockSignoffDetailsByUser(this.userId)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.loading = false;
          this.hardLockSignoffDetails = response;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage =
      "Something went wrong while fetching the hardware part numbers.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message;
    }

    console.error(errorMessage);
    this.loading = false;
  }

  getStatuses(): string[] {
    return Object.keys(this.hardLockSignoffDetails);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
