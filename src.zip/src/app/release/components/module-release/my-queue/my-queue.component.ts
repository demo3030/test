import {Component} from '@angular/core';

@Component({
  selector: 'app-my-queue',
  templateUrl: './my-queue.component.html',
  styleUrls: ['./my-queue.component.scss']
})
export class MyQueueComponent {}
