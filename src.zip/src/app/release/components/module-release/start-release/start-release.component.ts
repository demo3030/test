import { Component, OnInit } from '@angular/core';
import { SetupReleaseModel } from 'src/app/release/utils/models/start-release';
import { ReleaseService } from 'src/app/release/utils/services/release.service';

@Component({
  selector: 'app-start-release',
  templateUrl: './start-release.component.html',
  styleUrls: ['./start-release.component.scss']
})
export class StartReleaseComponent implements OnInit {

  setupReleaseData: SetupReleaseModel = new SetupReleaseModel();

  replacementParts: { label: string, value: string }[] = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
  ];

  moduleType: { label: string, value: string }[] = [];

  ngOnInit() {
    this.getModuleTypes();
  }

  constructor(
    private releaseService: ReleaseService
  ) { }


  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleType = res.map((moduleType: any) => ({
            label: moduleType.moduleTypeName,
            value: moduleType.moduleTypeCode
          }));
        } else {
          console.error('Something went wrong while fetching the module types.');
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

}
