import {Component} from '@angular/core';

@Component({
  selector: 'app-user-enrollment',
  templateUrl: './user-enrollment.component.html',
  styleUrls: ['./user-enrollment.component.scss']
})
export class UserEnrollmentComponent {}
